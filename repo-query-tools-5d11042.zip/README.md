# Repository Query Tools CLI

A CLI to query GitHub repositories data we're interested in: number of committers, presence of language and build tools.  
For each repository, it fetches all the latest files from the default branch and then applies patterns to determine if the file is of a certain type (language or build tool).

## Usage
### Prerequisites
To run the Repository Query Tools CLI JAR, you will need:

- A Java 21+ runtime available locally on the machine that you wish to execute the JAR on
- To download the JAR on the machine

### 1. Create an initial workspace
```shell
java -jar repo-query-tools-all.jar generate-workspace <path_to_dir>
```
This command will create the `<path_to_dir>` directory if it does not exist, and create a pre-filled configuration file for the tool.

### 2. Edit the configuration file at `<workspace_dir/config.yaml>`
The `config.yaml` file is pre-filled with sensible defaults and can be edited to limit the organizations, repositories and to customize detections.

### 3. Run the report
First, you need to provide a GitHub personal access token with repo scope by saving it to the file `<workspace_dir/github_token>`.
> [!IMPORTANT]  
> [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#fine-grained-personal-access-tokens) are not supported.

Alternatively, you can set it as an environment variable:
```shell
export GITHUB_TOKEN=ghp_xxx
```

Then you can run the report:
```shell
java -jar repo-query-tools-all.jar generate-report <workspace_dir>
```
The first time it runs, it can take several minutes depending on the number of organizations and repositories.
This will:
- Get all organizations the authenticated user is part of and match the configured exclude/include patterns
- For each organization, get the repositories according to the configured exclude/include patterns
- For each repository
  - Get the contributors and save their numbers to a cache
  - Get the latest tree from the default branch and save all the file paths to a cache
- Apply the language/build tool patterns to the file paths
- Output the results to a `run-YYYY-MM-HHMMSS/output.csv` file:

```
Repo,Contributor Count,Bazel,Gradle,Maven,c++,sbt
org1/repo1,6,false,false,false,false,false
org1/repo2,1,false,true,false,false,false
org2/repo1,3,false,true,false,false,false
org2/repo2,49,false,false,false,false,false
...
```

If you rerun the report, only the file paths matching will run, the file paths will be taken from the cache.   
If you need to fetch again the repository tree, you can remove the `<workspace_dir/org_dir/cache>` folder.

## Troubleshooting

After running the report, the workspace looks like this:
```
/workspace
├── cache
│ ├── orgs
│ │ └── org1
│ │ │   ├── repos
│ │ │   │ └── repo1
│ │ │   │ │   ├── contributor-count.txt
│ │ │   │ │   └── files.txt
│ │ │   │ └── repo2
│ │ │   │     ├── contributor-count.txt
│ │ │   │     └── files.txt
│ │ │   └── repos.txt
│ │ └── org2
│ │     ├── repos
│ │     │ └── repo1
│ │     │ │   ├── contributor-count.txt
│ │     │ │   └── files.txt
│ │     │ └── repo2
│ │     │     ├── contributor-count.txt
│ │     │     └── files.txt
│ │     └── repos.txt
│ └── orgs.txt
├── config.yaml
├── run-20240610-152213
│ ├── debug.log
│ └── report.csv
├── run-20240610-154518
│ ├── debug.log
│ └── report.csv
├── run-20240610-155105
│ ├── debug.log
│ └── report.csv
└── run-20240610-155315
    ├── debug.log
    └── report.csv
```

A log file is created per run in `run-YYYY-MM-HHMMSS/output.log` containing the effective configuration, the GitHub requests and stacktraces on exceptions.

